package com.example.service;

public interface FontService {
    public String[] generateRows(int amount);
}
