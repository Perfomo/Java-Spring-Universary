package com.example.dao;

public interface CollectionSearchDAO {
    public String findInfo(String key);
    public void changeInfo(String key, String info);
}
