package com.toleyko.service;

public interface FontService {
    public String[] generateRows(int amount);
}
